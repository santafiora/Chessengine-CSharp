﻿using quagga_01.Classes;
using quagga_01.Definitions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quagga_01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShowArray_Click(object sender, EventArgs e)
        {
            //UNIT TEST NUMMER_001 ARRAY AUF DER FORM AUSGEBEN
            textBox1.Clear();
            textBox1.SuspendLayout();
         
            var result = new StringBuilder();
           

            int index = 0;
            for (index = 0; index < Definition.SQ_NUM; ++index)
            {
                if (index % 10 == 0) result.Append(Environment.NewLine);
                result.Append(string.Format("{0}\t", Definition.SQ64(index)));
            }
            result.Append(Environment.NewLine);
            result.Append(Environment.NewLine);

            for (index = 0; index < 64; ++index)
            {
                if (index % 8 == 0) result.Append(Environment.NewLine);
                result.Append(string.Format("{0}\t", Definition.SQ120(index)));
            }


            textBox1.Text = result.ToString();

            textBox1.ResumeLayout();
        }

        private void btnPrtBoardStructure_Click(object sender, EventArgs e)
        {
            //UNIT TEST NUMMER_002 ARRAY AUF DER FORM AUSGEBEN MIT INDEXZAHLEN
            textBox1.Clear();
            textBox1.SuspendLayout();
           
            var result = new StringBuilder();
            var board = new Board();

            int index = 0;
            for (index = 0; index < Definition.SQ_NUM; ++index)
            {
                if (index % 10 == 0) result.Append(Environment.NewLine);
                result.Append(string.Format("{0}\t", Definition.SQ64(index)));
            }
            result.Append(Environment.NewLine);
            result.Append(Environment.NewLine);

            for (index = 0; index < 64; ++index)
            {
                if (index % 8 == 0) result.Append(Environment.NewLine);
                result.Append(string.Format("{0}\t", Definition.SQ120(index)));
            }


            textBox1.Text = result.ToString();

            textBox1.ResumeLayout();
        }
    }
}
