﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace quagga_01.Definitions
{
    public class Definition
    {
        //Felder
        public const int SQ_NUM = 120;
        public static int[] Sq120ToSq64 = new int[SQ_NUM];
        public static int[] Sq64ToSq120 = new int[64];
        public const int MAXGAMEMOVES = 2048; // So viele Züge gibt es in einer Schachpartie niemals ;-)
        //Seeschlange


        // Methoden

        public static int FR2SQ(int file, int rank)
        {
            return ((21 + file) + ((rank) * 10));
        }

        public static int SQ64(int sq120)
        {
            return Sq120ToSq64[sq120];
        }
        public static int SQ120(int sq64)
        {
            return Sq64ToSq120[sq64];
        }


        public struct UNDO
        {
            public int move;
            public int castlePerm;
            public int enPas;
            public int fiftyMove;
            public ulong posKey;
        }


    }
}
