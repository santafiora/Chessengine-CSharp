﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using quagga_01.Definitions;
using quagga_01.Enums;

//using static quagga_01.Definitions.Definition;


namespace quagga_01.Classes
{
   public class Board
    {
        public int[] pieces = new int[Definition.SQ_NUM];
        public ulong[] pawns = new ulong[3];

        public int[] KingSq = new int[2];
        public int side;
        public int enPas;
        public int fiftyMove;
        public int ply;
        public int hisPly;
        public int castlePerm;
        public ulong posKey;  

        public int[] pieceNum = new int[13];
        public int[] bigPieces = new int[2];
        public int[] majorPieces = new int[2];
        public int[] minorPieces = new int[2];
        public int[] material = new int[2];


        public Definition.UNDO[] history = new Definition.UNDO[Definition.MAXGAMEMOVES];



        #region constructor
        public Board()
        {
          InitSq120ToSq64();

        }
        #endregion


        public void InitSq120ToSq64()
        {
            int index = 0;
            int file = (int)Enums.File.FILE_A;
            int rank = (int)Rank.RANK_1;
            int sq = (int)Squares.A1;
            int sq64 = 0;
            for (index = 0; index < Definition.SQ_NUM; ++index)
            {
                Definition.Sq120ToSq64[index] = 65;
            }
            for (index = 0; index < 64; ++index)
            {
                Definition.Sq64ToSq120[index] = 120;
            }
            for (rank = (int)Rank.RANK_1; rank <= (int)Rank.RANK_8; ++rank)
            {
                for (file = (int)Enums.File.FILE_A; file <= (int)Enums.File.FILE_H; ++file)
                {
                    sq = Definition.FR2SQ(file, rank);
                    Definition.Sq64ToSq120[sq64] = sq;
                    Definition.Sq120ToSq64[sq] = sq64;
                    sq64++;
                }
            }
        }
    }
}
