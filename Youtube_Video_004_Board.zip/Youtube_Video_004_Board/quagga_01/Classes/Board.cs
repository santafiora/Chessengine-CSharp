﻿using quagga_01.Definitions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace quagga_01.Classes
{
    public class Board
    {
        public int[] pieces = new int[Definition.SQ_NUM]; // Alle Figuren
        public ulong[] pawns = new ulong[3];//Nur Bauern
        // public enum PieceColor
        // {
        //    WHITE, BLACK, BOTH
        // }
        /*
         * 00000000
         * 01000000
         * 00000000
         * 00000000
         * 00000000
         * 00000000
         * 00000000
         * 00000000
         * */
        // 01000000 00000000 00000000 00000000 00000000 
        // Sprich wo ist ein Bit eingeschaltet
        //Das macht die Bewertung der Stellung später einfacher ;-)
        // Welche Reihen oder Linien sind sind offen um diese mit Türmen zu besetzen
        //Das ermitteln von Bauernstrukturen oder eben auch wie weit ein Bauer vor der Umwandlung steht
      
        public int[] KingSq = new int[2]; // Wo befinden sich die Könige
        public int side; // Wer ist am Zug White or Black
        public int enPas;   // EnPassant 
        public int fiftyMove; //50 Züge Regel
        public int ply; // 1. e4 = Ply  e5 = Ply = ein Zug
        public int hisPly; // Welche Züge wurden gespielt um ständig auf Stellungswiederholung zu prüfen dann ist die Partie Remis
        public int castlePerm; //Rochade
        public ulong posKey; //Random Position key

        public int[] pieceNum = new int[13];// Wieviele Damen sind auf den Brett usw.....
        public int[] bigPieces = new int[2];// Alles was kein Bauer ist
        public int[] majorPieces = new int[2];// Türme und Damen
        public int[] minorPieces = new int[2];//Läufer Springer
        public int[] material = new int[2]; // Materialbewertung

    }
}
