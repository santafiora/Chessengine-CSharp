﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace quagga_01.Definitions
{
    public class Definition
    {
        //Felder
        public const int SQ_NUM = 120;
        public static int[] Sq120ToSq64 = new int[SQ_NUM];
        public static int[] Sq64ToSq120 = new int[64];



        // Methoden
        public static int SQ64(int sq120)
        {
            return Sq120ToSq64[sq120];
        }
        public static int SQ120(int sq64)
        {
            return Sq64ToSq120[sq64];
        }

    }
}
