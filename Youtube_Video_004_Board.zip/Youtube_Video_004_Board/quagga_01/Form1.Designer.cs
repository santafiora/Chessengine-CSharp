﻿
namespace quagga_01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tpSearchPV = new System.Windows.Forms.TabPage();
            this.tpAlphaBeta = new System.Windows.Forms.TabPage();
            this.btnShowArray = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pnlLeft = new System.Windows.Forms.Panel();
            this.pnlRight = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpAllgemein = new System.Windows.Forms.TabPage();
            this.tpParseMove = new System.Windows.Forms.TabPage();
            this.tpSearchMove = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tpSearch1 = new System.Windows.Forms.TabPage();
            this.pnlLeft.SuspendLayout();
            this.pnlRight.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpAllgemein.SuspendLayout();
            this.tpSearchMove.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tpSearchPV
            // 
            this.tpSearchPV.Location = new System.Drawing.Point(4, 29);
            this.tpSearchPV.Name = "tpSearchPV";
            this.tpSearchPV.Padding = new System.Windows.Forms.Padding(3);
            this.tpSearchPV.Size = new System.Drawing.Size(759, 792);
            this.tpSearchPV.TabIndex = 1;
            this.tpSearchPV.Text = "Search PV";
            this.tpSearchPV.UseVisualStyleBackColor = true;
            // 
            // tpAlphaBeta
            // 
            this.tpAlphaBeta.Location = new System.Drawing.Point(4, 29);
            this.tpAlphaBeta.Name = "tpAlphaBeta";
            this.tpAlphaBeta.Padding = new System.Windows.Forms.Padding(3);
            this.tpAlphaBeta.Size = new System.Drawing.Size(759, 792);
            this.tpAlphaBeta.TabIndex = 2;
            this.tpAlphaBeta.Text = "Alpha Beta";
            this.tpAlphaBeta.UseVisualStyleBackColor = true;
            // 
            // btnShowArray
            // 
            this.btnShowArray.Location = new System.Drawing.Point(12, 29);
            this.btnShowArray.Name = "btnShowArray";
            this.btnShowArray.Size = new System.Drawing.Size(187, 46);
            this.btnShowArray.TabIndex = 11;
            this.btnShowArray.Text = "Show Array";
            this.btnShowArray.UseVisualStyleBackColor = true;
            this.btnShowArray.Click += new System.EventHandler(this.btnShowArray_Click);
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(8, 8);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBox1.Size = new System.Drawing.Size(690, 848);
            this.textBox1.TabIndex = 0;
            // 
            // pnlLeft
            // 
            this.pnlLeft.Controls.Add(this.textBox1);
            this.pnlLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlLeft.Location = new System.Drawing.Point(0, 0);
            this.pnlLeft.Name = "pnlLeft";
            this.pnlLeft.Padding = new System.Windows.Forms.Padding(8);
            this.pnlLeft.Size = new System.Drawing.Size(706, 864);
            this.pnlLeft.TabIndex = 5;
            // 
            // pnlRight
            // 
            this.pnlRight.Controls.Add(this.btnShowArray);
            this.pnlRight.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlRight.Location = new System.Drawing.Point(3, 3);
            this.pnlRight.Name = "pnlRight";
            this.pnlRight.Size = new System.Drawing.Size(767, 825);
            this.pnlRight.TabIndex = 4;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpAllgemein);
            this.tabControl1.Controls.Add(this.tpParseMove);
            this.tabControl1.Controls.Add(this.tpSearchMove);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Right;
            this.tabControl1.Location = new System.Drawing.Point(706, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(781, 864);
            this.tabControl1.TabIndex = 4;
            // 
            // tpAllgemein
            // 
            this.tpAllgemein.Controls.Add(this.pnlRight);
            this.tpAllgemein.Location = new System.Drawing.Point(4, 29);
            this.tpAllgemein.Name = "tpAllgemein";
            this.tpAllgemein.Padding = new System.Windows.Forms.Padding(3);
            this.tpAllgemein.Size = new System.Drawing.Size(773, 831);
            this.tpAllgemein.TabIndex = 0;
            this.tpAllgemein.Text = "Allgemein";
            this.tpAllgemein.UseVisualStyleBackColor = true;
            // 
            // tpParseMove
            // 
            this.tpParseMove.Location = new System.Drawing.Point(4, 29);
            this.tpParseMove.Name = "tpParseMove";
            this.tpParseMove.Padding = new System.Windows.Forms.Padding(3);
            this.tpParseMove.Size = new System.Drawing.Size(773, 831);
            this.tpParseMove.TabIndex = 1;
            this.tpParseMove.Text = "Parse Move";
            this.tpParseMove.UseVisualStyleBackColor = true;
            // 
            // tpSearchMove
            // 
            this.tpSearchMove.Controls.Add(this.tabControl2);
            this.tpSearchMove.Location = new System.Drawing.Point(4, 29);
            this.tpSearchMove.Name = "tpSearchMove";
            this.tpSearchMove.Padding = new System.Windows.Forms.Padding(3);
            this.tpSearchMove.Size = new System.Drawing.Size(773, 831);
            this.tpSearchMove.TabIndex = 2;
            this.tpSearchMove.Text = "Search move";
            this.tpSearchMove.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tpSearch1);
            this.tabControl2.Controls.Add(this.tpSearchPV);
            this.tabControl2.Controls.Add(this.tpAlphaBeta);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(767, 825);
            this.tabControl2.TabIndex = 0;
            // 
            // tpSearch1
            // 
            this.tpSearch1.Location = new System.Drawing.Point(4, 29);
            this.tpSearch1.Name = "tpSearch1";
            this.tpSearch1.Padding = new System.Windows.Forms.Padding(3);
            this.tpSearch1.Size = new System.Drawing.Size(759, 792);
            this.tpSearch1.TabIndex = 0;
            this.tpSearch1.Text = "Search 1";
            this.tpSearch1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1487, 864);
            this.Controls.Add(this.pnlLeft);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnlLeft.ResumeLayout(false);
            this.pnlLeft.PerformLayout();
            this.pnlRight.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tpAllgemein.ResumeLayout(false);
            this.tpSearchMove.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tpSearchPV;
        private System.Windows.Forms.TabPage tpAlphaBeta;
        private System.Windows.Forms.Button btnShowArray;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel pnlLeft;
        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpAllgemein;
        private System.Windows.Forms.TabPage tpParseMove;
        private System.Windows.Forms.TabPage tpSearchMove;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tpSearch1;
    }
}

